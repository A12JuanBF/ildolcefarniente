<?php
include '../vistas/vista.php';
$vista = new vista;
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="Juan Diego Bermejo Fernández">
        <meta name="robots" content="Restaurante italiano, Santiago de Compostela, Il dolce far niente" />
        <meta name="Title" content="Galería">

        <meta name="twitter:card" content="summary">
        <meta name="twitter:site" content="">
        <meta name="twitter:title" content="Il dolce far niente">
        <meta name="twitter:description" content="">
        <meta name="twitter:creator" content="">

        <meta property="og:title" content="Il dolce far niente" />
        <meta property="og:url" content=" http://www.ildolcefarniente.es/" />
        <meta property="og:image" content="http://www.ildolcefarniente.es/images/logo1.jpg" />
        <meta property="og:description" content="" />

        <meta itemprop="name" content="Il dolce far niente">
        <meta itemprop="description" content="">
        <meta itemprop="image" content="http://www.ildolcefarniente.es/images/logo1.jpg"/>
        
        <title>Il dolce far niente | Galeria</title>

        <!-- core CSS -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link href="../css/font-awesome.min.css" rel="stylesheet">
        <link href="../css/prettyPhoto.css" rel="stylesheet">
        <link href="../css/animate.min.css" rel="stylesheet">
        <link href="../css/main.css" rel="stylesheet">
        <link href="../css/responsive.css" rel="stylesheet">

        <!--[if lt IE 9]>
        <script src="js/html5shiv.js"></script>
        <script src="js/respond.min.js"></script>
        <![endif]-->       
        <link rel="shortcut icon" href="../images/ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../images/ico/apple-touch-icon-144-precomposed.jpg">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../images/ico/apple-touch-icon-114-precomposed.jpg">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../images/ico/apple-touch-icon-72-precomposed.jpg">
        <link rel="apple-touch-icon-precomposed" href="../images/ico/apple-touch-icon-57-precomposed.jpg">
    </head><!--/head-->

    <body>

        <?php
        $vista->cabecero();
        ?>

        <section id="feature" class="transparent-bg">
            <div class="container">





                <div class="get-started center wow fadeInDown">
                    <h2>Ready to get started</h2>
                    <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore  magna aliqua. <br>  Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
                    <div class="request">
                        <h4><a href="#">Request a free Quote</a></h4>
                    </div>
                </div><!--/.get-started-->

                <section id="recent-works" class="shortcode-item">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item1.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme</a> </h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item1.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div>   

                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item2.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme</a></h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item2.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div> 

                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item1.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme </a></h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item1.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item4.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme </a></h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item4.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div>   

                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item5.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme</a></h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item5.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div>   

                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item6.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme </a></h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item6.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item10.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme </a></h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item10.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div>   

                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item8.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme </a></h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item8.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div> 
                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <div class="recent-work-wrap">
                                    <img class="img-responsive" src="../images/portfolio/recent/item12.jpg" alt="">
                                    <div class="overlay">
                                        <div class="recent-work-inner">
                                            <h3><a href="#">Business theme </a></h3>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                            <a class="preview" href="../images/portfolio/full/item12.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                        </div> 
                                    </div>
                                </div>
                            </div> 
                        </div>

                    </div>
                </section>


            </div><!--/.container-->
        </section><!--/#feature-->


        <?php
        $vista->menudesarrollado();
        ?>

        <?php
        $vista->pie();
        ?>


        <?php
        $vista->scripts();
        ?>
    </body>
</html>