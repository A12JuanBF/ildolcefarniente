<?php
include '../vistas/vista.php';
$vista = new vista;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="Juan Diego Bermejo Fernández">
        <meta name="robots" content="Restaurante italiano, Santiago de Compostela, Il dolce far niente" />
        <meta name="Title" content="Carta">

        <meta name="twitter:card" content="summary">
        <meta name="twitter:site" content="">
        <meta name="twitter:title" content="Il dolce far niente">
        <meta name="twitter:description" content="">
        <meta name="twitter:creator" content="">

        <meta property="og:title" content="Il dolce far niente" />
        <meta property="og:url" content=" http://www.ildolcefarniente.es/" />
        <meta property="og:image" content="http://www.ildolcefarniente.es/images/logo1.jpg" />
        <meta property="og:description" content="" />

        <meta itemprop="name" content="Il dolce far niente">
        <meta itemprop="description" content="">
        <meta itemprop="image" content="http://www.ildolcefarniente.es/images/logo1.jpg"/>
        
        
        <title>Il dolce far niente | Carta</title>
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link href="../css/font-awesome.min.css" rel="stylesheet">
        <link href="../css/prettyPhoto.css" rel="stylesheet">
        <link href="../css/animate.min.css" rel="stylesheet">
        <link href="../css/main.css" rel="stylesheet">
        <link href="../css/responsive.css" rel="stylesheet">
        <!--[if lt IE 9]>
        <script src="js/html5shiv.js"></script>
        <script src="js/respond.min.js"></script>
        <![endif]-->   
        <link rel="shortcut icon" href="../images/ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../images/ico/apple-touch-icon-144-precomposed.jpg">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../images/ico/apple-touch-icon-114-precomposed.jpg">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../images/ico/apple-touch-icon-72-precomposed.jpg">
        <link rel="apple-touch-icon-precomposed" href="../images/ico/apple-touch-icon-57-precomposed.jpg">
    </head><!--/head-->
    <body>

        <?php
        $vista->cabecero();
        ?>
        <section id="portfolio">
            <div class="container">
                <div class="center">
                    <h2>Menú</h2>
                    <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
                </div>


                <ul class="portfolio-filter text-center">
                    <li><a class="btn btn-default active" href="#" data-filter=".Entrantes">Entrantes</a></li>
                    <li><a class="btn btn-default" href="#" data-filter=".Ensalads">Ensaladas</a></li>
                    <li><a class="btn btn-default" href="#" data-filter=".Pizzas">Pizzas</a></li>
                    <li><a class="btn btn-default" href="#" data-filter=".Pastas">Pastas</a></li>
                    <li><a class="btn btn-default" href="#" data-filter=".Carnes">Carnes</a></li>
                    <li><a class="btn btn-default" href="#" data-filter=".Postres">Postres</a></li>
                </ul><!--/#portfolio-filter-->

                <div class="row">
                    <div class="portfolio-items">
                        <div class="portfolio-item Entrantes col-xs-12 col-sm-4 col-md-3">
                            <div class="recent-work-wrap">
                                <img class="img-responsive" src="../img-platos/entrante.jpg" alt="">
                                <div class="overlay">
                                    <div class="recent-work-inner">
                                        <h3><a href="#">Business theme</a></h3>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                        <a class="preview" href="../img-platos/entrante.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                    </div> 
                                </div>
                            </div>
                        </div><!--/.portfolio-item-->

                        <div  class="portfolio-item Pizzas col-xs-12 col-sm-4 col-md-3">
                            <div class="recent-work-wrap">
                                <img class="img-responsive" src="../img-platos/pizza.JPG" alt="Pizza" title="Pizza">
                                <div class="overlay">
                                    <div class="recent-work-inner">
                                        <h3><a href="#">Business theme</a></h3>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority </p>
                                        
                                        <a class="preview" href="../img-platos/pizza.JPG" rel="prettyPhoto"><span>Precio: 4,5 <i class="glyphicon glyphicon-euro"></i></span>&nbsp;<i class="fa fa-eye"></i> Ampliar imagen</a>
                                    </div> 
                                </div>
                            </div>          
                        </div><!--/.portfolio-item-->

                        <div class="portfolio-item Pastas col-xs-12 col-sm-4 col-md-3">
                            <div class="recent-work-wrap">
                                <img class="img-responsive" src="../img-platos/pasta.jpg" alt="">
                                <div class="overlay">
                                    <div class="recent-work-inner">
                                        <h3><a href="#">Business theme</a></h3>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                        <a class="preview" href="../img-platos/pasta.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                    </div> 
                                </div>
                            </div>        
                        </div><!--/.portfolio-item-->

                        <div class="portfolio-item Carnes apps col-xs-12 col-sm-4 col-md-3">
                            <div class="recent-work-wrap">
                                <img class="img-responsive" src="../img-platos/carne.jpg" alt="">
                                <div class="overlay">
                                    <div class="recent-work-inner">
                                        <h3><a href="#">Business theme</a></h3>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                        <a class="preview" href="../img-platos/carne.jpg" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                    </div> 
                                </div>
                            </div>           
                        </div><!--/.portfolio-item-->

                        <div class="portfolio-item Postres bootstrap col-xs-12 col-sm-4 col-md-3">
                            <div class="recent-work-wrap">
                                <img class="img-responsive" src="../img-platos/postre.JPG" alt="">
                                <div class="overlay">
                                    <div class="recent-work-inner">
                                        <h3><a href="#">Business theme</a></h3>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                                        <a class="preview" href="../img-platos/postre.JPG" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                                    </div> 
                                </div>
                            </div>      
                        </div><!--/.portfolio-item-->

                        

                        

                        
                    </div>
                </div>
            </div>
        </section><!--/#portfolio-item-->

        <?php 
        
        $vista->menudesarrollado();
        ?>
        <?php 
        
        $vista->pie();
        ?>
        
        <?php 
        
        $vista->scripts();
        ?>
    </body>
</html>
